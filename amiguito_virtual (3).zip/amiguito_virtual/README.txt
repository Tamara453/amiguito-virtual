# Amiguito Virtual

1. Asegúrate de colocar tu archivo `serviceAccountKey.json` en esta misma carpeta.
2. Reemplaza `'TU_BUCKET_NAME.appspot.com'` en `app.py` con el bucket de Firebase Storage real.
3. Instala las dependencias:
   pip install -r requirements.txt
4. Ejecuta la app:
   streamlit run app.py